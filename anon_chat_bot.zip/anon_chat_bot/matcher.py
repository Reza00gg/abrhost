"""In-memory matchmaking. No Telegram code here, so it is easy to test."""
import threading
import time


class Matcher:
    def __init__(self):
        self._lock = threading.Lock()
        self._queue = []      # waiting entries, oldest first
        self._partners = {}   # uid -> partner uid
        self._chat_no = {}    # uid -> opaque number of the current chat
        self._counter = 0

    # --- queries -----------------------------------------------------------
    def in_chat(self, uid):
        with self._lock:
            return uid in self._partners

    def is_waiting(self, uid):
        with self._lock:
            return self._index_of(uid) is not None

    def partner_of(self, uid):
        with self._lock:
            return self._partners.get(uid)

    def chat_no_of(self, uid):
        """Opaque id of the current chat (safe to put in callback data)."""
        with self._lock:
            return self._chat_no.get(uid)

    def stats(self):
        with self._lock:
            return {"waiting": len(self._queue), "chatting": len(self._partners)}

    # --- changes -----------------------------------------------------------
    def join(self, uid, gender, want="any", allowed=None):
        """Try to pair `uid` with someone waiting, otherwise queue them.

        Returns ("matched", other_entry), ("queued", None) or ("busy", None).
        `allowed(a, b)` may veto a pair (for example because of blocks).
        """
        with self._lock:
            if uid in self._partners or self._index_of(uid) is not None:
                return "busy", None
            me = {"uid": uid, "gender": gender, "want": want, "since": time.time()}
            for index, other in enumerate(self._queue):
                if self._compatible(me, other, allowed):
                    del self._queue[index]
                    self._pair(uid, other["uid"])
                    return "matched", other
            self._queue.append(me)
            return "queued", None

    def leave_queue(self, uid):
        with self._lock:
            index = self._index_of(uid)
            if index is None:
                return False
            del self._queue[index]
            return True

    def end_chat(self, uid):
        """End uid's chat. Returns the former partner, or None."""
        with self._lock:
            partner = self._partners.pop(uid, None)
            if partner is None:
                return None
            self._partners.pop(partner, None)
            self._chat_no.pop(uid, None)
            self._chat_no.pop(partner, None)
            return partner

    def expire(self, timeout, now=None):
        """Drop users waiting longer than `timeout`; returns their ids."""
        now = time.time() if now is None else now
        with self._lock:
            expired = [e["uid"] for e in self._queue if now - e["since"] >= timeout]
            self._queue = [e for e in self._queue if now - e["since"] < timeout]
            return expired

    # --- internals (call with the lock held) --------------------------------
    def _index_of(self, uid):
        for index, entry in enumerate(self._queue):
            if entry["uid"] == uid:
                return index
        return None

    @staticmethod
    def _compatible(a, b, allowed):
        if a["want"] != "any" and b["gender"] != a["want"]:
            return False
        if b["want"] != "any" and a["gender"] != b["want"]:
            return False
        if allowed is not None and not allowed(a["uid"], b["uid"]):
            return False
        return True

    def _pair(self, a, b):
        self._counter += 1
        self._partners[a] = b
        self._partners[b] = a
        self._chat_no[a] = self._counter
        self._chat_no[b] = self._counter
