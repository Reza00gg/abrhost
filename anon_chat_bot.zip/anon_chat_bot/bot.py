"""Anonymous chat bot for Telegram (pyTelegramBotAPI).

Run:  python bot.py      (needs BOT_TOKEN, see README.md)
"""
import logging
import random
import threading
import time
from collections import deque

import telebot
from telebot import types
from telebot.apihelper import ApiTelegramException

import config
import texts as T
from database import Database
from matcher import Matcher
from iran import PROVINCES
from questions import DARES, TRUTHS
from utils import (
    RateLimiter,
    clean_field,
    contains_contact_info,
    describe_distance,
    distance_km,
    normalize_digits,
    round_coord,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("anonbot")

if not config.TOKEN:
    raise SystemExit("BOT_TOKEN is not set. Copy .env.example to .env and fill it in.")

bot = telebot.TeleBot(config.TOKEN, parse_mode=None, threaded=True)
db = Database(config.DB_PATH)
matcher = Matcher()
limiter = RateLimiter(config.RATE_LIMIT_MESSAGES, config.RATE_LIMIT_WINDOW)
dm_limiter = RateLimiter(config.RATE_LIMIT_MESSAGES, config.RATE_LIMIT_WINDOW)

# Message types that are copied to the partner. Locations, contacts and polls
# are refused because they can reveal who someone is.
RELAY_TYPES = [
    "text", "photo", "voice", "video", "video_note",
    "sticker", "document", "audio", "animation",
]
REFUSED_TYPES = ["location", "contact", "venue", "poll", "dice", "game"]

# Menu button texts. Pressing one (or sending a /command) cancels a profile
# input that is waiting for the user's next message.
ALL_BUTTONS = {v for k, v in vars(T).items() if k.startswith("BTN_")} - {T.BTN_CANCEL_INPUT}
_pending = {}   # uid -> "name" | "city" | "photo" | "loc": what we are waiting for
_dm = {}        # uid -> friendship id: the user is typing direct messages to that friend
_dm_header = {}  # (receiver, friendship id) -> time the "message from X" header was sent

_bot_username = None


def bot_username():
    global _bot_username
    if _bot_username is None:
        _bot_username = bot.get_me().username
    return _bot_username


# ---------------------------------------------------------------------------
# keyboards
# ---------------------------------------------------------------------------
def main_menu():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row(T.BTN_RANDOM)
    kb.row(T.BTN_BOY, T.BTN_GIRL)
    kb.row(T.BTN_FRIENDS)
    kb.row(T.BTN_PROFILE, T.BTN_DAILY)
    kb.row(T.BTN_INVITE, T.BTN_HELP)
    return kb


def chat_menu():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row(T.BTN_NEXT, T.BTN_END)
    kb.row(T.BTN_GAME, T.BTN_FRIEND)
    kb.row(T.BTN_REPORT, T.BTN_BLOCK)
    return kb


def search_menu():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row(T.BTN_CANCEL)
    return kb


# ---------------------------------------------------------------------------
# sending helpers
# ---------------------------------------------------------------------------
def safe_send(uid, text, **kwargs):
    """send_message that never raises. Returns None on failure."""
    try:
        return bot.send_message(uid, text, **kwargs)
    except ApiTelegramException as exc:
        log.warning("send to %s failed: %s", uid, exc)
        if exc.error_code == 403:  # the user blocked the bot
            drop_user(uid)
        return None
    except Exception:  # network hiccups must not kill a handler thread
        log.exception("send to %s failed", uid)
        return None


def safe_photo(uid, file_id, caption=None, reply_markup=None):
    """send_photo that never raises (the file_id may have expired)."""
    try:
        return bot.send_photo(uid, file_id, caption=caption, reply_markup=reply_markup)
    except ApiTelegramException as exc:
        log.warning("photo to %s failed: %s", uid, exc)
        if exc.error_code == 403:
            drop_user(uid)
        return None
    except Exception:
        log.exception("photo to %s failed", uid)
        return None


def answer(call, text=None, alert=False):
    try:
        bot.answer_callback_query(call.id, text=text, show_alert=alert)
    except Exception:
        log.debug("answer_callback_query failed", exc_info=True)


def notify_admins(text):
    for admin_id in config.ADMIN_IDS:
        safe_send(admin_id, text)


# Only (sender, message_id) pairs of the last few messages of each running chat
# are kept, in memory only. They are used if - and only if - someone reports
# the chat, and are forgotten when the chat ends or the bot restarts.
_recent = {}
_recent_lock = threading.Lock()


def remember(chat_no, sender, message_id):
    with _recent_lock:
        buffer = _recent.setdefault(chat_no, deque(maxlen=config.EVIDENCE_MESSAGES))
        buffer.append((sender, message_id))


def take_evidence(chat_no):
    with _recent_lock:
        return list(_recent.pop(chat_no, ()))


_games = {}   # chat_no -> {"state": "invited"|"active", "inviter", "turn", "asked"}
_games_lock = threading.Lock()


def forget_game(chat_no):
    with _games_lock:
        _games.pop(chat_no, None)


def end_chat_forget(uid):
    """matcher.end_chat that also forgets message ids and any running game."""
    chat_no = matcher.chat_no_of(uid)
    partner = matcher.end_chat(uid)
    if chat_no is not None:
        take_evidence(chat_no)
        forget_game(chat_no)
    return partner


def ban_keyboard(uid, banned=False):
    """One-tap ban / unban button shown to admins under a report."""
    kb = types.InlineKeyboardMarkup()
    if banned:
        kb.add(types.InlineKeyboardButton(T.BTN_ADMIN_UNBAN, callback_data="ab:unban:%d" % uid))
    else:
        kb.add(types.InlineKeyboardButton(T.BTN_ADMIN_BAN, callback_data="ab:ban:%d" % uid))
    return kb


def send_evidence(reporter, reported, code, evidence):
    """After a report: show the admins the last messages of that chat."""
    if not config.ADMIN_IDS or not evidence:
        return
    header = "🚨 گزارش: %s\nگزارش‌دهنده: %d | گزارش‌شده: %d\n%d پیام آخر این چت:" % (
        T.REPORT_REASONS[code], reporter, reported, len(evidence),
    )
    reported_photo = (db.get_user(reported) or {}).get("photo")
    for admin_id in config.ADMIN_IDS:
        if not safe_send(admin_id, header, reply_markup=ban_keyboard(reported)):
            continue
        if reported_photo:
            safe_photo(admin_id, reported_photo, "🖼 عکس پروفایل گزارش‌شده")
        for sender, message_id in evidence:
            safe_send(admin_id, "↓ گزارش‌شده" if sender == reported else "↓ گزارش‌دهنده")
            try:
                bot.copy_message(admin_id, sender, message_id)
            except Exception:
                log.warning("could not copy evidence message %s to admin", message_id)


def drop_user(uid):
    """Remove a user who left (or blocked the bot) from queue and chat."""
    _pending.pop(uid, None)
    _dm.pop(uid, None)
    matcher.leave_queue(uid)
    partner = end_chat_forget(uid)
    if partner is not None:
        safe_send(partner, T.PARTNER_LEFT, reply_markup=main_menu())


# ---------------------------------------------------------------------------
# access checks
# ---------------------------------------------------------------------------
def check(message, need_ready=True):
    """Common gate for handlers. Returns the user row, or None if handled."""
    if message.chat.type != "private":
        return None
    uid = message.from_user.id
    if message.content_type == "text" and (
        message.text.startswith("/") or message.text in ALL_BUTTONS
    ):
        _pending.pop(uid, None)
        _dm.pop(uid, None)
    user = db.ensure_user(uid)
    if user["banned"]:
        _pending.pop(uid, None)
        safe_send(uid, T.BANNED)
        return None
    if user["state"] == "underage":
        safe_send(uid, T.AGE_TOO_YOUNG.format(min_age=config.MIN_AGE))
        return None
    db.touch(uid)
    if need_ready and user["state"] != "ready":
        continue_registration(uid, user)
        return None
    return user


def state_is(message, state):
    if message.chat.type != "private" or message.content_type != "text":
        return False
    user = db.get_user(message.from_user.id)
    return bool(user) and not user["banned"] and user["state"] == state


# ---------------------------------------------------------------------------
# registration: gender -> age -> ready
# ---------------------------------------------------------------------------
def ask_gender(uid, intro=None):
    db.set_profile(uid, state="gender")
    kb = types.InlineKeyboardMarkup()
    kb.row(
        types.InlineKeyboardButton(T.GENDER_LABEL["male"], callback_data="g:male"),
        types.InlineKeyboardButton(T.GENDER_LABEL["female"], callback_data="g:female"),
    )
    text = T.ASK_GENDER if not intro else intro + "\n\n" + T.ASK_GENDER
    safe_send(uid, text, reply_markup=kb)


def continue_registration(uid, user, intro=None):
    if user["state"] == "age":
        safe_send(uid, T.ASK_AGE)
    else:
        ask_gender(uid, intro)


@bot.message_handler(commands=["start"])
def on_start(message):
    if message.chat.type != "private":
        return
    uid = message.from_user.id
    existing = db.get_user(uid)

    ref = None
    parts = (message.text or "").split(maxsplit=1)
    if existing is None and len(parts) == 2 and parts[1].startswith("ref_"):
        candidate = parts[1][4:]
        if candidate.isdigit() and int(candidate) != uid and db.get_user(int(candidate)):
            ref = int(candidate)

    user = db.ensure_user(uid, ref_by=ref)
    if user["banned"]:
        safe_send(uid, T.BANNED)
    elif user["state"] == "underage":
        safe_send(uid, T.AGE_TOO_YOUNG.format(min_age=config.MIN_AGE))
    elif user["state"] == "ready":
        safe_send(uid, T.WELCOME_BACK, reply_markup=main_menu())
    else:
        safe_send(uid, T.RULES)
        continue_registration(uid, user, intro=T.WELCOME)


@bot.callback_query_handler(func=lambda c: c.data in ("g:male", "g:female"))
def on_gender(call):
    uid = call.from_user.id
    user = db.get_user(uid)
    if user is None or user["banned"] or user["state"] != "gender":
        answer(call)
        return
    gender = call.data.split(":")[1]
    db.set_profile(uid, gender=gender, state="age")
    answer(call)
    try:
        bot.edit_message_text(
            "جنسیت: " + T.GENDER_LABEL[gender],
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
        )
    except Exception:
        log.debug("edit_message_text failed", exc_info=True)
    safe_send(uid, T.ASK_AGE)


@bot.message_handler(func=lambda m: state_is(m, "age"))
def on_age(message):
    uid = message.from_user.id
    raw = normalize_digits((message.text or "").strip())
    if not raw.isdigit():
        safe_send(uid, T.AGE_INVALID)
        return
    age = int(raw)
    if age < config.MIN_AGE:
        # the age itself is not stored, only the fact that the user is not allowed
        db.set_profile(uid, state="underage")
        safe_send(uid, T.AGE_TOO_YOUNG.format(min_age=config.MIN_AGE))
        return
    if age > config.MAX_AGE:
        safe_send(uid, T.AGE_INVALID)
        return
    db.set_profile(uid, age=age, state="ready")
    safe_send(uid, T.REGISTERED, reply_markup=main_menu())
    referrer = db.reward_referrer(uid)
    if referrer is not None:
        safe_send(referrer, T.REFERRAL_REWARD.format(coins=config.REFERRAL_COINS))


# ---------------------------------------------------------------------------
# profile details: nickname, province, city, location, photo
# ---------------------------------------------------------------------------
def place_of(user):
    return " / ".join(x for x in (user["province"], user["city"]) if x)


def partner_info(info, me):
    """The lines shown to a user about the person they were just connected to."""
    lines = ["%s | %d ساله" % (T.GENDER_LABEL[info["gender"]], info["age"])]
    if info["nickname"]:
        lines.insert(0, "👤 " + info["nickname"])
    place = place_of(info)
    if place:
        lines.append("📍 " + place)
    if None not in (info["lat"], info["lon"], me["lat"], me["lon"]):
        km = distance_km(me["lat"], me["lon"], info["lat"], info["lon"])
        lines.append("📏 فاصله: " + describe_distance(km))
    return "\n".join(lines)


def profile_menu_keyboard(user):
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        types.InlineKeyboardButton(T.PF_NAME, callback_data="pf:name"),
        types.InlineKeyboardButton(T.PF_PROVINCE, callback_data="pf:prov"),
        types.InlineKeyboardButton(T.PF_CITY, callback_data="pf:city"),
        types.InlineKeyboardButton(T.PF_LOCATION, callback_data="pf:loc"),
        types.InlineKeyboardButton(T.PF_PHOTO, callback_data="pf:photo"),
        types.InlineKeyboardButton(T.PF_GENDER_AGE, callback_data="pf:gender"),
    )
    if user["lat"] is not None:
        kb.add(types.InlineKeyboardButton(T.PF_RM_LOCATION, callback_data="pf:rmloc"))
    if user["photo"]:
        kb.add(types.InlineKeyboardButton(T.PF_RM_PHOTO, callback_data="pf:rmphoto"))
    return kb


def cancel_keyboard(with_location=False):
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    if with_location:
        kb.row(types.KeyboardButton(T.BTN_SEND_LOCATION, request_location=True))
    kb.row(T.BTN_CANCEL_INPUT)
    return kb


PF_ACTIONS = ("name", "prov", "city", "loc", "photo", "rmloc", "rmphoto", "gender")


@bot.callback_query_handler(func=lambda c: c.data == "pf:edit")
def on_profile_edit(call):
    uid = call.from_user.id
    user = db.get_user(uid)
    if user is None or user["banned"] or user["state"] != "ready":
        answer(call)
        return
    if matcher.in_chat(uid) or matcher.is_waiting(uid):
        answer(call, T.PROFILE_EDIT_BLOCKED, alert=True)
        return
    answer(call)
    safe_send(uid, T.PROFILE_MENU, reply_markup=profile_menu_keyboard(user))


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("pf:") and c.data[3:] in PF_ACTIONS)
def on_profile_action(call):
    uid = call.from_user.id
    action = call.data[3:]
    user = db.get_user(uid)
    if user is None or user["banned"] or user["state"] != "ready":
        answer(call)
        return
    if matcher.in_chat(uid) or matcher.is_waiting(uid):
        answer(call, T.PROFILE_EDIT_BLOCKED, alert=True)
        return
    answer(call)

    if action == "gender":
        _pending.pop(uid, None)
        ask_gender(uid)
    elif action == "prov":
        _pending.pop(uid, None)
        kb = types.InlineKeyboardMarkup(row_width=3)
        kb.add(*[
            types.InlineKeyboardButton(name, callback_data="pv:%d" % index)
            for index, name in enumerate(PROVINCES)
        ])
        safe_send(uid, T.ASK_PROVINCE, reply_markup=kb)
    elif action == "name":
        _pending[uid] = "name"
        safe_send(uid, T.ASK_NAME.format(min=config.NAME_MIN, max=config.NAME_MAX),
                  reply_markup=cancel_keyboard())
    elif action == "city":
        _pending[uid] = "city"
        safe_send(uid, T.ASK_CITY, reply_markup=cancel_keyboard())
    elif action == "loc":
        _pending[uid] = "loc"
        safe_send(uid, T.ASK_LOCATION, reply_markup=cancel_keyboard(with_location=True))
    elif action == "photo":
        _pending[uid] = "photo"
        safe_send(uid, T.ASK_PHOTO, reply_markup=cancel_keyboard())
    elif action == "rmloc":
        db.set_profile(uid, lat=None, lon=None)
        safe_send(uid, T.LOCATION_REMOVED, reply_markup=main_menu())
    elif action == "rmphoto":
        db.set_profile(uid, photo=None)
        safe_send(uid, T.PHOTO_REMOVED, reply_markup=main_menu())


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("pv:"))
def on_province(call):
    uid = call.from_user.id
    user = db.get_user(uid)
    if user is None or user["banned"] or user["state"] != "ready":
        answer(call)
        return
    if matcher.in_chat(uid) or matcher.is_waiting(uid):
        answer(call, T.PROFILE_EDIT_BLOCKED, alert=True)
        return
    index = call.data[3:]
    if not index.isdigit() or int(index) >= len(PROVINCES):
        answer(call)
        return
    name = PROVINCES[int(index)]
    # a city from another province would be wrong, so it is cleared on change
    fields = {"province": name}
    if user["province"] != name:
        fields["city"] = None
    db.set_profile(uid, **fields)
    answer(call)
    _edit_or_ignore(call, T.PROVINCE_SAVED.format(value=name))


def _pending_input_wanted(message):
    if message.chat.type != "private" or message.from_user.id not in _pending:
        return False
    if message.content_type == "text":
        text = message.text or ""
        return not text.startswith("/") and text not in ALL_BUTTONS
    return message.content_type in ("photo", "location")


@bot.message_handler(content_types=["text", "photo", "location"], func=_pending_input_wanted)
def on_pending_input(message):
    user = check(message)
    uid = message.from_user.id
    kind = _pending.get(uid)
    if not user or kind is None:
        _pending.pop(uid, None)
        return
    if matcher.in_chat(uid) or matcher.is_waiting(uid):
        _pending.pop(uid, None)
        return
    if message.content_type == "text" and message.text == T.BTN_CANCEL_INPUT:
        _pending.pop(uid, None)
        safe_send(uid, T.PENDING_CANCELLED, reply_markup=main_menu())
        return

    if kind == "name" and message.content_type == "text":
        value = clean_field(message.text, config.NAME_MIN, config.NAME_MAX)
        if value is None:
            safe_send(uid, T.NAME_INVALID.format(min=config.NAME_MIN, max=config.NAME_MAX))
            return
        db.set_profile(uid, nickname=value)
        done = T.NAME_SAVED.format(value=value)
    elif kind == "city" and message.content_type == "text":
        value = clean_field(message.text, 2, 30)
        if value is None:
            safe_send(uid, T.CITY_INVALID)
            return
        db.set_profile(uid, city=value)
        done = T.CITY_SAVED.format(value=value)
    elif kind == "photo" and message.content_type == "photo":
        db.set_profile(uid, photo=message.photo[-1].file_id)
        done = T.PHOTO_SAVED
    elif kind == "loc" and message.content_type == "location":
        db.set_profile(
            uid,
            lat=round_coord(message.location.latitude, config.LOCATION_STEP),
            lon=round_coord(message.location.longitude, config.LOCATION_STEP),
        )
        done = T.LOCATION_SAVED
        try:  # do not leave the exact position lying in the chat history
            bot.delete_message(message.chat.id, message.message_id)
        except Exception:
            log.debug("delete_message failed", exc_info=True)
    else:
        safe_send(uid, T.WRONG_INPUT)
        return

    _pending.pop(uid, None)
    safe_send(uid, done, reply_markup=main_menu())


# ---------------------------------------------------------------------------
# searching, connecting, ending
# ---------------------------------------------------------------------------
def connect(uid, want, other):
    """Both users were paired by the matcher: charge, count and greet."""
    for who, wanted in ((uid, want), (other["uid"], other["want"])):
        if wanted != "any":
            db.spend_coins(who, config.FILTER_COST)
        db.increment_chats(who)
    for who, partner in ((uid, other["uid"]), (other["uid"], uid)):
        _dm.pop(who, None)
        info = db.get_user(partner)
        text = T.CONNECTED.format(info=partner_info(info, db.get_user(who)))
        # the profile photo and the details under it arrive as ONE message
        if not (info["photo"] and safe_photo(who, info["photo"], text, chat_menu())):
            safe_send(who, text, reply_markup=chat_menu())


def start_search(uid, want):
    user = db.get_user(uid)
    if matcher.in_chat(uid):
        safe_send(uid, T.ALREADY_IN_CHAT, reply_markup=chat_menu())
        return
    if matcher.is_waiting(uid):
        safe_send(uid, T.ALREADY_SEARCHING, reply_markup=search_menu())
        return
    if want != "any" and user["coins"] < config.FILTER_COST:
        safe_send(
            uid,
            T.NOT_ENOUGH_COINS.format(cost=config.FILTER_COST, coins=user["coins"]),
            reply_markup=main_menu(),
        )
        return
    status, other = matcher.join(
        uid, user["gender"], want, allowed=lambda a, b: not db.is_blocked(a, b)
    )
    if status == "queued":
        safe_send(uid, T.SEARCHING, reply_markup=search_menu())
    elif status == "matched":
        connect(uid, want, other)


def stop_current(uid):
    """Leave the queue or end the chat. Returns "search", "chat" or None."""
    if matcher.leave_queue(uid):
        return "search"
    partner = end_chat_forget(uid)
    if partner is not None:
        safe_send(partner, T.PARTNER_LEFT, reply_markup=main_menu())
        return "chat"
    return None


def search_handler(want):
    def handler(message):
        user = check(message)
        if user:
            start_search(message.from_user.id, want)
    return handler


for _label, _want in ((T.BTN_RANDOM, "any"), (T.BTN_BOY, "male"), (T.BTN_GIRL, "female")):
    bot.message_handler(func=lambda m, label=_label: m.text == label)(search_handler(_want))
bot.message_handler(commands=["find"])(search_handler("any"))


@bot.message_handler(commands=["stop"])
@bot.message_handler(func=lambda m: m.text in (T.BTN_END, T.BTN_CANCEL))
def on_stop(message):
    user = check(message)
    if not user:
        return
    uid = message.from_user.id
    result = stop_current(uid)
    if result == "search":
        safe_send(uid, T.SEARCH_CANCELLED, reply_markup=main_menu())
    elif result == "chat":
        safe_send(uid, T.CHAT_ENDED, reply_markup=main_menu())
    else:
        safe_send(uid, T.NOT_IN_CHAT, reply_markup=main_menu())


@bot.message_handler(commands=["next"])
@bot.message_handler(func=lambda m: m.text == T.BTN_NEXT)
def on_next(message):
    user = check(message)
    if not user:
        return
    uid = message.from_user.id
    if not matcher.in_chat(uid):
        if matcher.is_waiting(uid):
            safe_send(uid, T.ALREADY_SEARCHING, reply_markup=search_menu())
        else:
            safe_send(uid, T.NOT_IN_CHAT, reply_markup=main_menu())
        return
    stop_current(uid)
    start_search(uid, "any")


# ---------------------------------------------------------------------------
# reports and blocks
# ---------------------------------------------------------------------------
@bot.message_handler(commands=["report"])
@bot.message_handler(func=lambda m: m.text == T.BTN_REPORT)
def on_report(message):
    user = check(message)
    if not user:
        return
    uid = message.from_user.id
    chat_no = matcher.chat_no_of(uid)
    if chat_no is None:
        safe_send(uid, T.NOT_IN_CHAT, reply_markup=main_menu())
        return
    # callback data carries an opaque chat number, never the partner's Telegram id
    kb = types.InlineKeyboardMarkup(row_width=1)
    for code, label in T.REPORT_REASONS.items():
        kb.add(types.InlineKeyboardButton(label, callback_data="rp:%s:%s" % (code, chat_no)))
    kb.add(types.InlineKeyboardButton(T.BTN_CANCEL_REPORT, callback_data="rp:x:0"))
    safe_send(uid, T.REPORT_ASK, reply_markup=kb)


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("rp:"))
def on_report_choice(call):
    uid = call.from_user.id
    parts = call.data.split(":")
    if len(parts) != 3:
        answer(call)
        return
    _, code, chat_no = parts
    if code == "x":
        answer(call, T.CANCELLED)
        _edit_or_ignore(call, T.CANCELLED)
        return
    partner = matcher.partner_of(uid)
    if (
        partner is None
        or code not in T.REPORT_REASONS
        or str(matcher.chat_no_of(uid)) != chat_no
    ):
        answer(call, T.REPORT_STALE, alert=True)
        _edit_or_ignore(call, T.REPORT_STALE)
        return

    current_chat = matcher.chat_no_of(uid)
    evidence = take_evidence(current_chat)
    forget_game(current_chat)
    db.add_report(uid, partner, code)
    db.add_block(uid, partner)
    matcher.end_chat(uid)
    send_evidence(uid, partner, code, evidence)
    answer(call)
    _edit_or_ignore(call, T.REPORT_DONE)

    banned = db.count_reporters(partner) >= config.REPORTS_TO_BAN
    if banned:
        db.set_banned(partner, True)
        notify_admins("🚫 کاربر %s بعد از %d گزارش خودکار مسدود شد." % (partner, config.REPORTS_TO_BAN))
        safe_send(partner, T.BANNED)
    else:
        safe_send(partner, T.PARTNER_LEFT, reply_markup=main_menu())
    if code == "min":
        notify_admins("⚠️ گزارش «مشکوک به زیر ۱۸ سال» برای کاربر %s ثبت شد." % partner)
    safe_send(uid, T.CHAT_ENDED, reply_markup=main_menu())


def _edit_or_ignore(call, text, reply_markup=None):
    try:
        bot.edit_message_text(
            text,
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            reply_markup=reply_markup,
        )
    except Exception:
        log.debug("edit_message_text failed", exc_info=True)


@bot.message_handler(commands=["block"])
@bot.message_handler(func=lambda m: m.text == T.BTN_BLOCK)
def on_block(message):
    user = check(message)
    if not user:
        return
    uid = message.from_user.id
    partner = matcher.partner_of(uid)
    if partner is None:
        safe_send(uid, T.NOT_IN_CHAT, reply_markup=main_menu())
        return
    db.add_block(uid, partner)
    end_chat_forget(uid)
    safe_send(uid, T.BLOCK_DONE, reply_markup=main_menu())
    safe_send(partner, T.PARTNER_LEFT, reply_markup=main_menu())


# ---------------------------------------------------------------------------
# profile, coins, help
# ---------------------------------------------------------------------------
@bot.message_handler(commands=["profile"])
@bot.message_handler(func=lambda m: m.text == T.BTN_PROFILE)
def on_profile(message):
    user = check(message)
    if not user:
        return
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton(T.BTN_EDIT_PROFILE, callback_data="pf:edit"))
    text = T.PROFILE.format(
        nickname=user["nickname"] or T.NOT_SET,
        gender=T.GENDER_LABEL[user["gender"]],
        age=user["age"],
        place=place_of(user) or T.NOT_SET,
        location=T.SET_YES if user["lat"] is not None else T.SET_NO,
        photo=T.SET_YES if user["photo"] else T.SET_NO,
        coins=user["coins"],
        referrals=user["referrals"],
        chats=user["chats"],
    )
    if not (user["photo"] and safe_photo(user["id"], user["photo"], text, kb)):
        safe_send(user["id"], text, reply_markup=kb)


@bot.message_handler(commands=["daily"])
@bot.message_handler(func=lambda m: m.text == T.BTN_DAILY)
def on_daily(message):
    user = check(message)
    if not user:
        return
    uid = user["id"]
    if db.claim_daily(uid):
        total = db.get_user(uid)["coins"]
        safe_send(uid, T.DAILY_OK.format(coins=config.DAILY_COINS, total=total))
    else:
        safe_send(uid, T.DAILY_DONE)


@bot.message_handler(commands=["invite"])
@bot.message_handler(func=lambda m: m.text == T.BTN_INVITE)
def on_invite(message):
    user = check(message)
    if not user:
        return
    link = "https://t.me/%s?start=ref_%d" % (bot_username(), user["id"])
    safe_send(user["id"], T.INVITE.format(link=link, coins=config.REFERRAL_COINS))


@bot.message_handler(commands=["help"])
@bot.message_handler(func=lambda m: m.text == T.BTN_HELP)
def on_help(message):
    if check(message, need_ready=False):
        safe_send(message.from_user.id, T.HELP)


@bot.message_handler(commands=["rules"])
def on_rules(message):
    if check(message, need_ready=False):
        safe_send(message.from_user.id, T.RULES)


# ---------------------------------------------------------------------------
# admin commands (ADMIN_IDS only). Admins cannot read chats.
# ---------------------------------------------------------------------------
def is_admin(message):
    return message.chat.type == "private" and message.from_user.id in config.ADMIN_IDS


def parse_args(message, count):
    """Split '/cmd a b' into `count` arguments; None if malformed."""
    parts = (message.text or "").split(maxsplit=count)
    if len(parts) != count + 1:
        return None
    return parts[1:]


@bot.message_handler(commands=["admin"])
def on_admin(message):
    if not is_admin(message):
        return
    stats = db.stats()
    live = matcher.stats()
    safe_send(
        message.from_user.id,
        "📊 آمار\n"
        "کاربران: %(users)d (ثبت‌نام‌شده: %(ready)d)\n"
        "مسدود: %(banned)d\n"
        "چت‌های انجام‌شده: %(chats)d\n"
        "گزارش‌ها: %(reports)d\n"
        "الان در جستجو: %(waiting)d | در چت: %(chatting)d\n\n"
        "/ban <id>\n/unban <id>\n/addcoins <id> <n>\n/broadcast <متن>"
        % {**stats, **live},
    )


@bot.message_handler(commands=["ban", "unban"])
def on_ban(message):
    if not is_admin(message):
        return
    args = parse_args(message, 1)
    if not args or not args[0].isdigit():
        safe_send(message.from_user.id, "مثال: /ban 123456789")
        return
    target = int(args[0])
    banning = message.text.startswith("/ban")
    db.set_banned(target, banning)
    if banning:
        drop_user(target)
        safe_send(target, T.BANNED)
    safe_send(message.from_user.id, "%s: %d" % ("مسدود شد" if banning else "آزاد شد", target))


@bot.message_handler(commands=["addcoins"])
def on_addcoins(message):
    if not is_admin(message):
        return
    args = parse_args(message, 2)
    if not args or not args[0].isdigit() or not args[1].lstrip("-").isdigit():
        safe_send(message.from_user.id, "مثال: /addcoins 123456789 10")
        return
    ok = db.add_coins(int(args[0]), int(args[1]))
    safe_send(message.from_user.id, "انجام شد." if ok else "کاربر پیدا نشد.")


@bot.message_handler(commands=["broadcast"])
def on_broadcast(message):
    if not is_admin(message):
        return
    args = parse_args(message, 1)
    if not args:
        safe_send(message.from_user.id, "مثال: /broadcast سلام به همه!")
        return
    threading.Thread(
        target=run_broadcast, args=(message.from_user.id, args[0]), daemon=True
    ).start()


def run_broadcast(admin_id, text):
    sent = failed = 0
    for uid in db.all_user_ids():
        if safe_send(uid, text):
            sent += 1
        else:
            failed += 1
        time.sleep(config.BROADCAST_DELAY)
    safe_send(admin_id, "📣 ارسال تموم شد: %d موفق، %d ناموفق" % (sent, failed))


# ---------------------------------------------------------------------------
# truth or dare: starts only if the partner accepts; turns alternate
# ---------------------------------------------------------------------------
def _game_button(text, action, chat_no):
    return types.InlineKeyboardButton(text, callback_data="td:%s:%d" % (action, chat_no))


def choice_keyboard(chat_no):
    kb = types.InlineKeyboardMarkup()
    kb.row(_game_button(T.BTN_TRUTH, "truth", chat_no), _game_button(T.BTN_DARE, "dare", chat_no))
    kb.row(_game_button(T.BTN_GAME_END, "end", chat_no))
    return kb


def done_keyboard(chat_no):
    kb = types.InlineKeyboardMarkup()
    kb.row(_game_button(T.BTN_GAME_DONE, "done", chat_no))
    kb.row(_game_button(T.BTN_GAME_END, "end", chat_no))
    return kb


def give_turn(chat_no, uid):
    safe_send(uid, T.GAME_YOUR_TURN, reply_markup=choice_keyboard(chat_no))
    other = matcher.partner_of(uid)
    if other is not None:
        safe_send(other, T.GAME_PARTNER_TURN)


@bot.message_handler(commands=["game"])
@bot.message_handler(func=lambda m: m.text == T.BTN_GAME)
def on_game(message):
    user = check(message)
    if not user:
        return
    uid = user["id"]
    partner = matcher.partner_of(uid)
    chat_no = matcher.chat_no_of(uid)
    if partner is None or chat_no is None:
        safe_send(uid, T.NOT_IN_CHAT, reply_markup=main_menu())
        return

    with _games_lock:
        game = _games.get(chat_no)
        if game is None:
            _games[chat_no] = {"state": "invited", "inviter": uid, "turn": None, "asked": False}
            action = "invite"
        elif game["state"] == "invited" and game["inviter"] != uid:
            action = "reinvite"
        elif game["state"] == "invited":
            action = "waiting"
        else:
            action = "active"

    if action == "invite":
        kb = types.InlineKeyboardMarkup()
        kb.row(_game_button(T.BTN_GAME_YES, "yes", chat_no), _game_button(T.BTN_GAME_NO, "no", chat_no))
        safe_send(partner, T.GAME_INVITE, reply_markup=kb)
        safe_send(uid, T.GAME_INVITE_SENT)
    elif action == "reinvite":
        kb = types.InlineKeyboardMarkup()
        kb.row(_game_button(T.BTN_GAME_YES, "yes", chat_no), _game_button(T.BTN_GAME_NO, "no", chat_no))
        safe_send(uid, T.GAME_INVITE, reply_markup=kb)
    elif action == "waiting":
        safe_send(uid, T.GAME_INVITE_SENT)
    else:
        kb = types.InlineKeyboardMarkup()
        kb.row(_game_button(T.BTN_GAME_END, "end", chat_no))
        safe_send(uid, T.GAME_ACTIVE, reply_markup=kb)


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("td:"))
def on_game_button(call):
    uid = call.from_user.id
    parts = call.data.split(":")
    if len(parts) != 3:
        answer(call)
        return
    _, action, chat_no_text = parts
    partner = matcher.partner_of(uid)
    chat_no = matcher.chat_no_of(uid)
    if partner is None or str(chat_no) != chat_no_text:
        answer(call, T.GAME_STALE, alert=True)
        _edit_or_ignore(call, T.GAME_STALE)
        return

    question = kind = None
    with _games_lock:
        game = _games.get(chat_no)
        if game is None:
            outcome = "stale"
        elif action == "no" and game["state"] == "invited" and game["inviter"] != uid:
            del _games[chat_no]
            outcome = "declined"
        elif action == "yes" and game["state"] == "invited" and game["inviter"] != uid:
            game.update(state="active", turn=game["inviter"], asked=False)
            outcome = "started"
        elif (
            action in ("truth", "dare")
            and game["state"] == "active"
            and game["turn"] == uid
            and not game["asked"]
        ):
            game["asked"] = True  # ignore double taps
            kind = T.BTN_TRUTH if action == "truth" else T.BTN_DARE
            question = random.choice(TRUTHS if action == "truth" else DARES)
            outcome = "asked"
        elif action == "done" and game["state"] == "active" and game["turn"] == uid and game["asked"]:
            game.update(turn=partner, asked=False)
            outcome = "next"
        elif action == "end" and game["state"] in ("invited", "active"):
            del _games[chat_no]
            outcome = "ended"
        else:
            outcome = "ignored"

    answer(call)
    if outcome == "stale":
        _edit_or_ignore(call, T.GAME_STALE)
    elif outcome == "declined":
        _edit_or_ignore(call, T.GAME_DECLINED_SELF)
        safe_send(partner, T.GAME_DECLINED)
    elif outcome == "started":
        _edit_or_ignore(call, T.GAME_STARTED)
        safe_send(partner, T.GAME_STARTED)
        give_turn(chat_no, partner)  # the inviter goes first
    elif outcome == "asked":
        _edit_or_ignore(
            call,
            T.GAME_QUESTION_SELF.format(kind=kind, question=question),
            reply_markup=done_keyboard(chat_no),
        )
        safe_send(partner, T.GAME_QUESTION_OTHER.format(kind=kind, question=question))
    elif outcome == "next":
        _edit_or_ignore(call, T.GAME_DONE)
        give_turn(chat_no, partner)
    elif outcome == "ended":
        _edit_or_ignore(call, T.GAME_ENDED)
        safe_send(partner, T.GAME_ENDED)


# ---------------------------------------------------------------------------
# friends and direct messages (through the bot; Telegram ids are never shown)
# ---------------------------------------------------------------------------
def friend_name(friend_user, fid):
    return friend_user["nickname"] or T.FRIEND_DEFAULT_NAME.format(fid=fid)


def _int(text):
    return int(text) if text.isdigit() else None


@bot.message_handler(commands=["friend"])
@bot.message_handler(func=lambda m: m.text == T.BTN_FRIEND)
def on_friend(message):
    user = check(message)
    if not user:
        return
    uid = user["id"]
    partner = matcher.partner_of(uid)
    if partner is None:
        safe_send(uid, T.NOT_IN_CHAT, reply_markup=main_menu())
        return

    status, ref = db.create_request(uid, partner)
    if status == "sent":
        kb = types.InlineKeyboardMarkup()
        kb.row(
            types.InlineKeyboardButton(T.BTN_ACCEPT, callback_data="fq:yes:%d" % ref),
            types.InlineKeyboardButton(T.BTN_DECLINE, callback_data="fq:no:%d" % ref),
        )
        safe_send(partner, T.FRIEND_REQUEST_RECEIVED, reply_markup=kb)
        safe_send(uid, T.FRIEND_REQUEST_SENT)
    elif status == "mutual":
        safe_send(uid, T.FRIEND_ACCEPTED_SELF)
        safe_send(partner, T.FRIEND_ACCEPTED_SELF)
    elif status == "friends":
        safe_send(uid, T.ALREADY_FRIENDS)
    elif status == "pending":
        safe_send(uid, T.REQUEST_PENDING)
    elif status == "limit":
        safe_send(uid, T.FRIEND_LIMIT.format(max=config.MAX_FRIENDS))
    else:
        safe_send(uid, T.FRIEND_NOT_POSSIBLE)


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("fq:"))
def on_friend_answer(call):
    uid = call.from_user.id
    parts = call.data.split(":")
    if len(parts) != 3 or parts[1] not in ("yes", "no") or _int(parts[2]) is None:
        answer(call)
        return
    user = db.get_user(uid)
    if user is None or user["banned"]:
        answer(call)
        return
    status, requester = db.answer_request(int(parts[2]), uid, parts[1] == "yes")
    answer(call)
    if status == "accepted":
        _edit_or_ignore(call, T.FRIEND_ACCEPTED_SELF)
        safe_send(requester, T.FRIEND_ACCEPTED_OTHER)
    elif status == "declined":
        _edit_or_ignore(call, T.FRIEND_DECLINED_SELF)   # the requester is not told
    elif status == "limit":
        _edit_or_ignore(call, T.FRIEND_LIMIT.format(max=config.MAX_FRIENDS))
    else:
        _edit_or_ignore(call, T.REQUEST_STALE)


@bot.message_handler(commands=["friends"])
@bot.message_handler(func=lambda m: m.text == T.BTN_FRIENDS)
def on_friends(message):
    user = check(message)
    if not user:
        return
    uid = user["id"]
    rows = db.friends_of(uid)
    if not rows:
        safe_send(uid, T.FRIENDS_EMPTY, reply_markup=main_menu())
        return
    kb = types.InlineKeyboardMarkup(row_width=1)
    for row in rows:
        name = friend_name(db.get_user(row["friend_id"]), row["fid"])
        kb.add(types.InlineKeyboardButton(name, callback_data="fr:%d" % row["fid"]))
    safe_send(
        uid,
        T.FRIENDS_LIST.format(count=len(rows), max=config.MAX_FRIENDS),
        reply_markup=kb,
    )


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("fr:"))
def on_friend_card(call):
    """Show a friend's profile: photo and details in one message, plus actions."""
    uid = call.from_user.id
    fid = _int(call.data[3:])
    friend = db.friend_of(fid, uid) if fid is not None else None
    if friend is None:
        answer(call, T.FRIEND_STALE, alert=True)
        return
    answer(call)
    info, me = db.get_user(friend), db.get_user(uid)
    text = "👤 %s\n%s" % (friend_name(info, fid), partner_info(info, me))
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(T.FR_SEND, callback_data="fm:send:%d" % fid),
        types.InlineKeyboardButton(T.FR_DELETE, callback_data="fm:del:%d" % fid),
        types.InlineKeyboardButton(T.FR_BLOCK, callback_data="fm:blk:%d" % fid),
    )
    if not (info["photo"] and safe_photo(uid, info["photo"], text, kb)):
        safe_send(uid, text, reply_markup=kb)


def dm_keyboard():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row(T.BTN_DM_STOP)
    return kb


def start_dm(uid, fid, friend):
    if matcher.in_chat(uid) or matcher.is_waiting(uid):
        safe_send(uid, T.DM_BUSY)
        return
    _pending.pop(uid, None)
    _dm[uid] = fid
    name = friend_name(db.get_user(friend), fid)
    safe_send(uid, T.DM_ASK.format(name=name), reply_markup=dm_keyboard())


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("fm:"))
def on_friend_action(call):
    uid = call.from_user.id
    parts = call.data.split(":")
    fid = _int(parts[2]) if len(parts) == 3 else None
    friend = db.friend_of(fid, uid) if fid is not None else None
    if friend is None or parts[1] not in ("send", "del", "blk"):
        answer(call, T.FRIEND_STALE, alert=True)
        return
    answer(call)
    if parts[1] == "send":
        start_dm(uid, fid, friend)
        return
    if _dm.get(uid) == fid:
        _dm.pop(uid, None)
    if parts[1] == "blk":
        db.add_block(uid, friend)   # also removes the friendship
        safe_send(uid, T.FRIEND_BLOCK_DONE, reply_markup=main_menu())
    else:
        db.remove_friendship(fid)
        safe_send(uid, T.FRIEND_DELETED, reply_markup=main_menu())


@bot.message_handler(func=lambda m: m.text == T.BTN_DM_STOP)
def on_dm_stop(message):
    if check(message):   # check() already left direct-message mode
        safe_send(message.from_user.id, T.DM_STOPPED, reply_markup=main_menu())


def relay_dm(uid, message, text):
    """Deliver one message from `uid` to the friend they are writing to."""
    fid = _dm[uid]
    friend = db.friend_of(fid, uid)
    if friend is None or db.is_blocked(uid, friend):
        _dm.pop(uid, None)
        safe_send(uid, T.DM_NOT_FRIENDS, reply_markup=main_menu())
        return
    if not dm_limiter.allow(uid):
        safe_send(uid, T.SLOW_DOWN)
        return
    if config.BLOCK_CONTACT_INFO and contains_contact_info(text):
        safe_send(uid, T.CONTACT_BLOCKED)
        return

    now = time.time()
    if now - _dm_header.get((friend, fid), 0) > config.DM_HEADER_SECONDS:
        name = friend_name(db.get_user(uid), fid)
        safe_send(friend, T.DM_HEADER.format(name=name))
        _dm_header[(friend, fid)] = now
    kb = types.InlineKeyboardMarkup()
    kb.row(
        types.InlineKeyboardButton(T.DM_REPLY, callback_data="dm:reply:%d" % fid),
        types.InlineKeyboardButton(T.DM_REPORT, callback_data="dm:report:%d" % fid),
    )
    try:
        bot.copy_message(friend, message.chat.id, message.message_id, reply_markup=kb)
    except ApiTelegramException as exc:
        log.warning("dm %s -> %s failed: %s", uid, friend, exc)
        safe_send(uid, T.DM_FAILED)


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("dm:"))
def on_dm_button(call):
    uid = call.from_user.id
    parts = call.data.split(":")
    fid = _int(parts[2]) if len(parts) == 3 else None
    friend = db.friend_of(fid, uid) if fid is not None else None
    if friend is None or parts[1] not in ("reply", "report"):
        answer(call, T.FRIEND_STALE, alert=True)
        return
    answer(call)
    if parts[1] == "reply":
        start_dm(uid, fid, friend)
        return
    # the id of the message carrying the button is the one being reported
    mid = call.message.message_id
    kb = types.InlineKeyboardMarkup(row_width=1)
    for code, label in T.REPORT_REASONS.items():
        kb.add(types.InlineKeyboardButton(label, callback_data="dr:%s:%d:%d" % (code, fid, mid)))
    kb.add(types.InlineKeyboardButton(T.BTN_CANCEL_REPORT, callback_data="dr:x:0:0"))
    safe_send(uid, T.DM_REPORT_ASK, reply_markup=kb)


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("dr:"))
def on_dm_report(call):
    uid = call.from_user.id
    parts = call.data.split(":")
    if len(parts) != 4:
        answer(call)
        return
    code, fid, mid = parts[1], _int(parts[2]), _int(parts[3])
    if code == "x":
        answer(call, T.CANCELLED)
        _edit_or_ignore(call, T.CANCELLED)
        return
    friend = db.friend_of(fid, uid) if fid is not None else None
    if friend is None or mid is None or code not in T.REPORT_REASONS:
        answer(call, T.FRIEND_STALE, alert=True)
        _edit_or_ignore(call, T.FRIEND_STALE)
        return

    db.add_report(uid, friend, code)
    db.add_block(uid, friend)        # blocks and ends the friendship
    _dm.pop(uid, None)
    answer(call)
    _edit_or_ignore(call, T.DM_REPORT_DONE)

    # only the one reported message goes to the admins, with the reported
    # user's profile photo, exactly like a report from a random chat
    photo = (db.get_user(friend) or {}).get("photo")
    header = "🚨 گزارش پیام دوستانه: %s\nگزارش‌دهنده: %d | گزارش‌شده: %d\nپیام گزارش‌شده:" % (
        T.REPORT_REASONS[code], uid, friend,
    )
    for admin_id in config.ADMIN_IDS:
        if not safe_send(admin_id, header, reply_markup=ban_keyboard(friend)):
            continue
        if photo:
            safe_photo(admin_id, photo, "🖼 عکس پروفایل گزارش‌شده")
        try:
            bot.copy_message(admin_id, uid, mid)
        except Exception:
            log.warning("could not copy reported dm %s to admin", mid)

    if db.count_reporters(friend) >= config.REPORTS_TO_BAN:
        db.set_banned(friend, True)
        drop_user(friend)
        notify_admins("🚫 کاربر %s بعد از %d گزارش خودکار مسدود شد." % (friend, config.REPORTS_TO_BAN))
        safe_send(friend, T.BANNED)
    if code == "min":
        notify_admins("⚠️ گزارش «مشکوک به زیر ۱۸ سال» برای کاربر %s ثبت شد." % friend)


@bot.callback_query_handler(func=lambda c: (c.data or "").startswith("ab:"))
def on_admin_ban_button(call):
    """One-tap ban/unban from a report message. Admins only."""
    if call.from_user.id not in config.ADMIN_IDS:
        answer(call)
        return
    parts = call.data.split(":")
    target = _int(parts[2]) if len(parts) == 3 else None
    if target is None or parts[1] not in ("ban", "unban"):
        answer(call)
        return
    answer(call)
    if parts[1] == "ban":
        db.set_banned(target, True)
        drop_user(target)
        safe_send(target, T.BANNED)
        _edit_or_ignore(call, T.ADMIN_BANNED.format(uid=target), reply_markup=ban_keyboard(target, banned=True))
    else:
        db.set_banned(target, False)
        _edit_or_ignore(call, T.ADMIN_UNBANNED.format(uid=target), reply_markup=ban_keyboard(target))


# ---------------------------------------------------------------------------
# relaying messages between partners (keep these handlers LAST)
# ---------------------------------------------------------------------------
@bot.message_handler(content_types=RELAY_TYPES)
def on_message(message):
    user = check(message)
    if not user:
        return
    uid = user["id"]
    text = message.text or message.caption or ""

    if message.content_type == "text" and text.startswith("/"):
        safe_send(uid, T.UNKNOWN_COMMAND)
        return

    partner = matcher.partner_of(uid)
    if partner is None and uid in _dm and not matcher.is_waiting(uid):
        relay_dm(uid, message, text)
        return
    if partner is None:
        if matcher.is_waiting(uid):
            safe_send(uid, T.ALREADY_SEARCHING, reply_markup=search_menu())
        else:
            safe_send(uid, T.NOT_IN_CHAT, reply_markup=main_menu())
        return

    if not limiter.allow(uid):
        safe_send(uid, T.SLOW_DOWN)
        return
    if config.BLOCK_CONTACT_INFO and contains_contact_info(text):
        safe_send(uid, T.CONTACT_BLOCKED)
        return

    try:
        # copy_message hides the sender and works for every media type
        bot.copy_message(partner, message.chat.id, message.message_id)
        remember(matcher.chat_no_of(uid), uid, message.message_id)
    except ApiTelegramException as exc:
        log.warning("relay %s -> %s failed: %s", uid, partner, exc)
        if exc.error_code == 403:
            drop_user(partner)
            safe_send(uid, T.PARTNER_LEFT, reply_markup=main_menu())
        else:
            safe_send(uid, T.SEND_FAILED)


@bot.message_handler(content_types=REFUSED_TYPES)
def on_unsupported(message):
    if check(message):
        safe_send(message.from_user.id, T.UNSUPPORTED)


# ---------------------------------------------------------------------------
# background cleanup + entry point
# ---------------------------------------------------------------------------
def janitor():
    """Release users who waited too long without finding a partner."""
    while True:
        time.sleep(30)
        try:
            for uid in matcher.expire(config.SEARCH_TIMEOUT):
                safe_send(uid, T.SEARCH_TIMEOUT, reply_markup=main_menu())
        except Exception:
            log.exception("janitor failed")


def main():
    username = bot_username()
    bot.set_my_commands([
        types.BotCommand("start", "شروع"),
        types.BotCommand("find", "چت تصادفی"),
        types.BotCommand("next", "نفر بعدی"),
        types.BotCommand("stop", "پایان چت"),
        types.BotCommand("game", "جرأت یا حقیقت"),
        types.BotCommand("friend", "درخواست دوستی"),
        types.BotCommand("friends", "دوستان و پیام دایرکت"),
        types.BotCommand("report", "گزارش"),
        types.BotCommand("block", "بلاک"),
        types.BotCommand("profile", "پروفایل"),
        types.BotCommand("daily", "هدیه روزانه"),
        types.BotCommand("invite", "دعوت دوستان"),
        types.BotCommand("help", "راهنما"),
        types.BotCommand("rules", "قوانین"),
    ])
    threading.Thread(target=janitor, daemon=True).start()
    log.info("started as @%s", username)
    bot.infinity_polling(skip_pending=True)


if __name__ == "__main__":
    main()
