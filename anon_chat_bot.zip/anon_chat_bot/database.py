"""SQLite storage: users, coins, reports and blocks.

Message contents are never stored - only who reported/blocked whom.
"""
import sqlite3
import threading
from datetime import datetime, timedelta, timezone

import config

TEHRAN = timezone(timedelta(hours=3, minutes=30))
PROFILE_FIELDS = (
    "gender", "age", "state", "nickname", "province", "city", "lat", "lon", "photo",
)
# Added after the first release: created on old databases by _migrate().
EXTRA_COLUMNS = (
    ("nickname", "TEXT"),
    ("province", "TEXT"),
    ("city", "TEXT"),
    ("lat", "REAL"),
    ("lon", "REAL"),
    ("photo", "TEXT"),
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id           INTEGER PRIMARY KEY,
    gender       TEXT,
    age          INTEGER,
    state        TEXT    NOT NULL DEFAULT 'new',
    coins        INTEGER NOT NULL DEFAULT 0,
    banned       INTEGER NOT NULL DEFAULT 0,
    ref_by       INTEGER,
    ref_rewarded INTEGER NOT NULL DEFAULT 0,
    referrals    INTEGER NOT NULL DEFAULT 0,
    chats        INTEGER NOT NULL DEFAULT 0,
    last_daily   TEXT,
    created_at   TEXT    NOT NULL,
    last_seen    TEXT    NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter   INTEGER NOT NULL,
    reported   INTEGER NOT NULL,
    reason     TEXT    NOT NULL,
    created_at TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_reports_reported ON reports (reported);
CREATE TABLE IF NOT EXISTS blocks (
    user_id    INTEGER NOT NULL,
    blocked_id INTEGER NOT NULL,
    PRIMARY KEY (user_id, blocked_id)
);
CREATE TABLE IF NOT EXISTS friendships (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    a          INTEGER NOT NULL,
    b          INTEGER NOT NULL,
    created_at TEXT    NOT NULL,
    UNIQUE (a, b)
);
CREATE TABLE IF NOT EXISTS friend_requests (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    from_id    INTEGER NOT NULL,
    to_id      INTEGER NOT NULL,
    status     TEXT    NOT NULL DEFAULT 'pending',
    created_at TEXT    NOT NULL
);
"""


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def today_tehran():
    return datetime.now(TEHRAN).strftime("%Y-%m-%d")


class Database:
    def __init__(self, path=":memory:"):
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._migrate()
            self._conn.commit()

    def _migrate(self):
        have = {row["name"] for row in self._conn.execute("PRAGMA table_info(users)")}
        for name, decl in EXTRA_COLUMNS:
            if name not in have:
                self._conn.execute("ALTER TABLE users ADD COLUMN %s %s" % (name, decl))

    # --- low level ---------------------------------------------------------
    def _write(self, sql, params=()):
        with self._lock:
            cursor = self._conn.execute(sql, params)
            self._conn.commit()
            return cursor.rowcount

    def _all(self, sql, params=()):
        with self._lock:
            return [dict(row) for row in self._conn.execute(sql, params).fetchall()]

    def _one(self, sql, params=()):
        rows = self._all(sql, params)
        return rows[0] if rows else None

    # --- users -------------------------------------------------------------
    def get_user(self, uid):
        return self._one("SELECT * FROM users WHERE id = ?", (uid,))

    def ensure_user(self, uid, ref_by=None):
        stamp = now_iso()
        self._write(
            "INSERT OR IGNORE INTO users (id, coins, ref_by, created_at, last_seen) "
            "VALUES (?, ?, ?, ?, ?)",
            (uid, config.START_COINS, ref_by, stamp, stamp),
        )
        return self.get_user(uid)

    def touch(self, uid):
        self._write("UPDATE users SET last_seen = ? WHERE id = ?", (now_iso(), uid))

    def set_profile(self, uid, **fields):
        unknown = set(fields) - set(PROFILE_FIELDS)
        if unknown:
            raise ValueError("unknown profile fields: %s" % ", ".join(sorted(unknown)))
        if not fields:
            return
        assignments = ", ".join("%s = ?" % name for name in fields)
        self._write(
            "UPDATE users SET %s WHERE id = ?" % assignments, (*fields.values(), uid)
        )

    def increment_chats(self, uid):
        self._write("UPDATE users SET chats = chats + 1 WHERE id = ?", (uid,))

    def set_banned(self, uid, banned):
        self.ensure_user(uid)
        self._write("UPDATE users SET banned = ? WHERE id = ?", (1 if banned else 0, uid))

    def all_user_ids(self):
        rows = self._all("SELECT id FROM users WHERE state = 'ready' AND banned = 0")
        return [row["id"] for row in rows]

    # --- coins -------------------------------------------------------------
    def add_coins(self, uid, amount):
        return self._write(
            "UPDATE users SET coins = coins + ? WHERE id = ?", (amount, uid)
        ) == 1

    def spend_coins(self, uid, amount):
        """Atomically subtract coins; False if the balance is too low."""
        return self._write(
            "UPDATE users SET coins = coins - ? WHERE id = ? AND coins >= ?",
            (amount, uid, amount),
        ) == 1

    def claim_daily(self, uid):
        """Give the daily gift once per day (Tehran time). True if given."""
        return self._write(
            "UPDATE users SET coins = coins + ?, last_daily = ? "
            "WHERE id = ? AND (last_daily IS NULL OR last_daily != ?)",
            (config.DAILY_COINS, today_tehran(), uid, today_tehran()),
        ) == 1

    def reward_referrer(self, uid):
        """Pay the referrer once, after `uid` finished registering.

        Returns the referrer's id, or None if nobody was paid.
        """
        claimed = self._write(
            "UPDATE users SET ref_rewarded = 1 "
            "WHERE id = ? AND ref_by IS NOT NULL AND ref_rewarded = 0",
            (uid,),
        )
        if claimed != 1:
            return None
        referrer = self.get_user(uid)["ref_by"]
        paid = self._write(
            "UPDATE users SET coins = coins + ?, referrals = referrals + 1 "
            "WHERE id = ? AND banned = 0",
            (config.REFERRAL_COINS, referrer),
        )
        return referrer if paid == 1 else None

    # --- reports and blocks --------------------------------------------------
    def add_report(self, reporter, reported, reason):
        self._write(
            "INSERT INTO reports (reporter, reported, reason, created_at) "
            "VALUES (?, ?, ?, ?)",
            (reporter, reported, reason, now_iso()),
        )

    def count_reporters(self, reported):
        row = self._one(
            "SELECT COUNT(DISTINCT reporter) AS n FROM reports WHERE reported = ?",
            (reported,),
        )
        return row["n"]

    def add_block(self, uid, blocked):
        """Block someone. This also ends any friendship between the two."""
        a, b = self._pair(uid, blocked)
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO blocks (user_id, blocked_id) VALUES (?, ?)",
                (uid, blocked),
            )
            self._conn.execute("DELETE FROM friendships WHERE a = ? AND b = ?", (a, b))
            self._conn.commit()

    # --- friends -------------------------------------------------------------
    # Friends talk through the bot. The only id ever sent to a client is the
    # friendship id, never the other person's Telegram id.
    @staticmethod
    def _pair(x, y):
        return (x, y) if x < y else (y, x)

    def friendship_between(self, x, y):
        a, b = self._pair(x, y)
        row = self._one("SELECT id FROM friendships WHERE a = ? AND b = ?", (a, b))
        return row["id"] if row else None

    def count_friends(self, uid):
        row = self._one(
            "SELECT COUNT(*) AS n FROM friendships WHERE a = ? OR b = ?", (uid, uid)
        )
        return row["n"]

    def friends_of(self, uid):
        rows = self._all(
            "SELECT id, a, b FROM friendships WHERE a = ? OR b = ? ORDER BY id", (uid, uid)
        )
        return [
            {"fid": r["id"], "friend_id": r["b"] if r["a"] == uid else r["a"]} for r in rows
        ]

    def friend_of(self, fid, uid):
        """The other person of friendship `fid`, or None if uid is not part of it."""
        row = self._one("SELECT a, b FROM friendships WHERE id = ?", (fid,))
        if row is None or uid not in (row["a"], row["b"]):
            return None
        return row["b"] if row["a"] == uid else row["a"]

    def remove_friendship(self, fid):
        self._write("DELETE FROM friendships WHERE id = ?", (fid,))

    def _make_friends(self, x, y):
        a, b = self._pair(x, y)
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO friendships (a, b, created_at) VALUES (?, ?, ?)",
                (a, b, now_iso()),
            )
            self._conn.commit()
        return self.friendship_between(x, y)

    def _friend_limit_reached(self, x, y):
        return (
            self.count_friends(x) >= config.MAX_FRIENDS
            or self.count_friends(y) >= config.MAX_FRIENDS
        )

    def create_request(self, frm, to):
        """Returns (status, id): sent / mutual / friends / pending / blocked / limit."""
        with self._lock:
            if self.is_blocked(frm, to):
                return "blocked", None
            if self.friendship_between(frm, to) is not None:
                return "friends", None
            reverse = self._one(
                "SELECT id FROM friend_requests "
                "WHERE from_id = ? AND to_id = ? AND status = 'pending'",
                (to, frm),
            )
            if self._friend_limit_reached(frm, to):
                return "limit", None
            if reverse is not None:  # both asked each other: they are friends now
                self._write(
                    "UPDATE friend_requests SET status = 'accepted' WHERE id = ?",
                    (reverse["id"],),
                )
                return "mutual", self._make_friends(frm, to)
            if self._one(
                "SELECT id FROM friend_requests "
                "WHERE from_id = ? AND to_id = ? AND status = 'pending'",
                (frm, to),
            ):
                return "pending", None
            cursor = self._conn.execute(
                "INSERT INTO friend_requests (from_id, to_id, created_at) VALUES (?, ?, ?)",
                (frm, to, now_iso()),
            )
            self._conn.commit()
            return "sent", cursor.lastrowid

    def answer_request(self, rid, uid, accept):
        """The receiver `uid` answers request `rid`.

        Returns (status, requester_id) with status accepted / declined /
        blocked / limit / stale.
        """
        with self._lock:
            req = self._one(
                "SELECT from_id FROM friend_requests "
                "WHERE id = ? AND to_id = ? AND status = 'pending'",
                (rid, uid),
            )
            if req is None:
                return "stale", None
            frm = req["from_id"]
            if not accept:
                self._write("UPDATE friend_requests SET status = 'declined' WHERE id = ?", (rid,))
                return "declined", frm
            if self.is_blocked(uid, frm):
                self._write("UPDATE friend_requests SET status = 'declined' WHERE id = ?", (rid,))
                return "blocked", frm
            if self._friend_limit_reached(uid, frm):
                return "limit", frm
            self._make_friends(uid, frm)
            self._write("UPDATE friend_requests SET status = 'accepted' WHERE id = ?", (rid,))
            return "accepted", frm

    def is_blocked(self, a, b):
        """True if either user blocked the other."""
        row = self._one(
            "SELECT 1 AS hit FROM blocks "
            "WHERE (user_id = ? AND blocked_id = ?) OR (user_id = ? AND blocked_id = ?)",
            (a, b, b, a),
        )
        return row is not None

    # --- stats -------------------------------------------------------------
    def stats(self):
        users = self._one(
            "SELECT COUNT(*) AS total, "
            "COALESCE(SUM(state = 'ready'), 0) AS ready, "
            "COALESCE(SUM(banned), 0) AS banned, "
            "COALESCE(SUM(chats), 0) AS chats FROM users"
        )
        reports = self._one("SELECT COUNT(*) AS n FROM reports")
        return {
            "users": users["total"],
            "ready": users["ready"],
            "banned": users["banned"],
            "chats": users["chats"] // 2,
            "reports": reports["n"],
        }
