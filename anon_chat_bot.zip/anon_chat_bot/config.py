"""Bot settings. Secrets come from environment variables or a .env file."""
import os


def _load_env_file(path):
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _int_set(value):
    result = set()
    for part in value.split(","):
        part = part.strip()
        if part.isdigit():
            result.add(int(part))
    return result


_load_env_file(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

# --- secrets / deployment ---------------------------------------------------
TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = _int_set(os.getenv("ADMIN_IDS", ""))
DB_PATH = os.getenv("DB_PATH", "bot.db")

# --- users ------------------------------------------------------------------
MIN_AGE = 18
MAX_AGE = 80

# --- profile ----------------------------------------------------------------
NAME_MIN = 2
NAME_MAX = 20
LOCATION_STEP = 0.05          # degrees (~5 km): saved coordinates are rounded to this grid

# --- coins ------------------------------------------------------------------
START_COINS = 5       # given on first contact
DAILY_COINS = 2       # daily gift
REFERRAL_COINS = 3    # for each friend who finishes registration
FILTER_COST = 2       # cost of choosing the partner's gender

# --- friends and direct messages ----------------------------------------------
MAX_FRIENDS = 30
DM_HEADER_SECONDS = 60        # "message from X" header is repeated after this much silence

# --- safety -----------------------------------------------------------------
REPORTS_TO_BAN = 3            # distinct reporters before an automatic ban
BLOCK_CONTACT_INFO = True     # refuse links, @usernames and phone numbers
EVIDENCE_MESSAGES = 10        # last N messages of a chat sent to admins if it is reported
RATE_LIMIT_MESSAGES = 8       # max messages ...
RATE_LIMIT_WINDOW = 10        # ... per this many seconds

# --- matching ---------------------------------------------------------------
SEARCH_TIMEOUT = 300          # seconds before a waiting user is released

# --- admin broadcast --------------------------------------------------------
BROADCAST_DELAY = 0.05        # seconds between messages (Telegram flood limits)
