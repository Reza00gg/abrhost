"""Small helpers: digit normalisation, contact-info filter, rate limiter."""
import math
import re
import threading
import time
from collections import defaultdict, deque

_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")

_URL = re.compile(r"(https?://|www\.|t\.me/|telegram\.me/|telegram\.dog/)", re.I)
_HANDLE = re.compile(r"(?<![\w])@[A-Za-z][A-Za-z0-9_]{3,}")
_PHONE = re.compile(r"(?:\d[\s\-().]*){9,}")


def normalize_digits(text):
    """Turn Persian/Arabic digits into ASCII digits."""
    return (text or "").translate(_DIGITS)


def contains_contact_info(text):
    """True if the text has a link, an @username or a phone-number-like run."""
    if not text:
        return False
    plain = normalize_digits(text)
    return bool(_URL.search(plain) or _HANDLE.search(plain) or _PHONE.search(plain))


def clean_field(text, min_len=2, max_len=20):
    """Validate a short free-text profile field (nickname, city).

    Returns the cleaned text, or None if it is too short/long, only digits,
    or contains a link, @username or phone number.
    """
    value = " ".join((text or "").split())
    if not (min_len <= len(value) <= max_len):
        return None
    if normalize_digits(value).isdigit():
        return None
    if contains_contact_info(value):
        return None
    return value


def round_coord(value, step=0.05):
    """Snap a latitude/longitude to a coarse grid so the exact spot is never kept."""
    return round(round(value / step) * step, 4)


def distance_km(lat1, lon1, lat2, lon2):
    """Great-circle distance (haversine) in kilometres."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    d_lat = p2 - p1
    d_lon = math.radians(lon2 - lon1)
    a = math.sin(d_lat / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(d_lon / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(a))


def describe_distance(km):
    """Coarse, human-friendly distance: never more precise than 10 km."""
    if km < 10:
        return "کمتر از ۱۰ کیلومتر"
    return "حدود %d کیلومتر" % (round(km / 10) * 10)


class RateLimiter:
    """Sliding-window limiter: at most `limit` hits per `window` seconds per key."""

    def __init__(self, limit, window):
        self.limit = limit
        self.window = window
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key, now=None):
        now = time.monotonic() if now is None else now
        with self._lock:
            hits = self._hits[key]
            while hits and now - hits[0] > self.window:
                hits.popleft()
            if len(hits) >= self.limit:
                return False
            hits.append(now)
            return True
