"""Tests for the parts that do not need Telegram: database, matcher, utils.

Run from the project folder:  python -m unittest discover -s tests -v
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config  # noqa: E402
from database import Database  # noqa: E402
from matcher import Matcher  # noqa: E402
from utils import RateLimiter, contains_contact_info, normalize_digits  # noqa: E402


class UtilsTests(unittest.TestCase):
    def test_normalize_digits(self):
        self.assertEqual(normalize_digits("۲۳"), "23")
        self.assertEqual(normalize_digits("٢٣"), "23")

    def test_contact_info_detected(self):
        for text in (
            "t.me/someone",
            "https://example.com",
            "www.example.com",
            "آیدی من @my_name هست",
            "09123456789",
            "۰۹۱۲ ۳۴۵ ۶۷۸۹",
            "0912-345-6789",
        ):
            self.assertTrue(contains_contact_info(text), text)

    def test_normal_text_allowed(self):
        for text in ("سلام چطوری؟", "من ۲۳ سالمه", "email me", "", None, "a@b"):
            self.assertFalse(contains_contact_info(text), text)

    def test_rate_limiter(self):
        limiter = RateLimiter(limit=3, window=10)
        self.assertTrue(all(limiter.allow("u", now=t) for t in (0, 1, 2)))
        self.assertFalse(limiter.allow("u", now=3))
        self.assertTrue(limiter.allow("other", now=3))
        self.assertTrue(limiter.allow("u", now=11))  # window slid forward


class MatcherTests(unittest.TestCase):
    def setUp(self):
        self.m = Matcher()

    def test_two_users_are_paired(self):
        self.assertEqual(self.m.join(1, "male")[0], "queued")
        status, other = self.m.join(2, "female")
        self.assertEqual(status, "matched")
        self.assertEqual(other["uid"], 1)
        self.assertEqual(self.m.partner_of(1), 2)
        self.assertEqual(self.m.partner_of(2), 1)
        self.assertEqual(self.m.chat_no_of(1), self.m.chat_no_of(2))

    def test_busy_users_cannot_join_twice(self):
        self.m.join(1, "male")
        self.assertEqual(self.m.join(1, "male")[0], "busy")
        self.m.join(2, "female")
        self.assertEqual(self.m.join(2, "female")[0], "busy")

    def test_gender_filter(self):
        self.m.join(1, "male", want="female")
        self.assertEqual(self.m.join(2, "male")[0], "queued")      # 1 wants a girl
        status, other = self.m.join(3, "female")
        self.assertEqual(status, "matched")
        self.assertEqual(other["uid"], 1)
        self.assertTrue(self.m.is_waiting(2))

    def test_both_filters_must_agree(self):
        self.m.join(1, "male", want="female")
        self.assertEqual(self.m.join(2, "female", want="female")[0], "queued")

    def test_allowed_callback_can_veto(self):
        self.m.join(1, "male")
        status, _ = self.m.join(2, "female", allowed=lambda a, b: False)
        self.assertEqual(status, "queued")
        self.assertTrue(self.m.is_waiting(1))
        self.assertTrue(self.m.is_waiting(2))

    def test_end_chat_frees_both(self):
        self.m.join(1, "male")
        self.m.join(2, "female")
        self.assertEqual(self.m.end_chat(1), 2)
        self.assertFalse(self.m.in_chat(1))
        self.assertFalse(self.m.in_chat(2))
        self.assertIsNone(self.m.chat_no_of(2))
        self.assertIsNone(self.m.end_chat(1))

    def test_leave_queue(self):
        self.m.join(1, "male")
        self.assertTrue(self.m.leave_queue(1))
        self.assertFalse(self.m.leave_queue(1))

    def test_expire(self):
        self.m.join(1, "male")
        self.assertEqual(self.m.expire(timeout=300, now=0), [])
        expired = self.m.expire(timeout=300, now=10 ** 12)
        self.assertEqual(expired, [1])
        self.assertFalse(self.m.is_waiting(1))

    def test_chat_numbers_are_unique(self):
        self.m.join(1, "male")
        self.m.join(2, "female")
        first = self.m.chat_no_of(1)
        self.m.end_chat(1)
        self.m.join(1, "male")
        self.m.join(2, "female")
        self.assertNotEqual(first, self.m.chat_no_of(1))


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")

    def test_new_user_gets_start_coins(self):
        user = self.db.ensure_user(10)
        self.assertEqual(user["coins"], config.START_COINS)
        self.assertEqual(user["state"], "new")
        self.assertEqual(self.db.ensure_user(10)["coins"], config.START_COINS)

    def test_profile_update_and_whitelist(self):
        self.db.ensure_user(10)
        self.db.set_profile(10, gender="male", age=25, state="ready")
        user = self.db.get_user(10)
        self.assertEqual((user["gender"], user["age"], user["state"]), ("male", 25, "ready"))
        with self.assertRaises(ValueError):
            self.db.set_profile(10, coins=999)

    def test_spend_coins_is_checked(self):
        self.db.ensure_user(10)
        self.assertTrue(self.db.spend_coins(10, config.START_COINS))
        self.assertFalse(self.db.spend_coins(10, 1))
        self.assertEqual(self.db.get_user(10)["coins"], 0)

    def test_daily_gift_once_per_day(self):
        self.db.ensure_user(10)
        self.assertTrue(self.db.claim_daily(10))
        self.assertFalse(self.db.claim_daily(10))
        self.assertEqual(
            self.db.get_user(10)["coins"], config.START_COINS + config.DAILY_COINS
        )

    def test_referral_paid_once(self):
        self.db.ensure_user(1)
        self.db.ensure_user(2, ref_by=1)
        self.assertEqual(self.db.reward_referrer(2), 1)
        self.assertIsNone(self.db.reward_referrer(2))
        referrer = self.db.get_user(1)
        self.assertEqual(referrer["coins"], config.START_COINS + config.REFERRAL_COINS)
        self.assertEqual(referrer["referrals"], 1)

    def test_no_referral_without_referrer(self):
        self.db.ensure_user(3)
        self.assertIsNone(self.db.reward_referrer(3))

    def test_reports_count_distinct_reporters(self):
        for reporter in (1, 1, 2):
            self.db.add_report(reporter, 99, "ins")
        self.assertEqual(self.db.count_reporters(99), 2)

    def test_blocks_work_both_ways(self):
        self.assertFalse(self.db.is_blocked(1, 2))
        self.db.add_block(1, 2)
        self.assertTrue(self.db.is_blocked(1, 2))
        self.assertTrue(self.db.is_blocked(2, 1))
        self.db.add_block(1, 2)  # duplicate is fine

    def test_ban_and_broadcast_list(self):
        for uid in (1, 2, 3):
            self.db.ensure_user(uid)
            self.db.set_profile(uid, state="ready")
        self.db.set_banned(2, True)
        self.assertEqual(sorted(self.db.all_user_ids()), [1, 3])
        self.db.set_banned(2, False)
        self.assertEqual(sorted(self.db.all_user_ids()), [1, 2, 3])

    def test_stats(self):
        self.db.ensure_user(1)
        self.db.ensure_user(2)
        self.db.set_profile(1, state="ready")
        self.db.set_banned(2, True)
        self.db.increment_chats(1)
        self.db.increment_chats(2)
        self.db.add_report(1, 2, "spm")
        stats = self.db.stats()
        self.assertEqual(
            stats, {"users": 2, "ready": 1, "banned": 1, "chats": 1, "reports": 1}
        )


class ProfileHelperTests(unittest.TestCase):
    def test_clean_field(self):
        from utils import clean_field

        self.assertEqual(clean_field("  سارا   جون "), "سارا جون")
        for bad in ("", "a", "x" * 21, "12345", "۱۲۳۴", "@my_id", "t.me/abc", "0912 345 6789", None):
            self.assertIsNone(clean_field(bad), bad)
        self.assertEqual(clean_field("شیراز", 2, 30), "شیراز")

    def test_round_coord_hides_exact_spot(self):
        from utils import round_coord

        lat = round_coord(35.69439, 0.05)
        self.assertAlmostEqual(lat, 35.7, places=4)
        self.assertEqual(round_coord(lat, 0.05), lat)           # idempotent
        self.assertLess(abs(round_coord(51.3890, 0.05) - 51.3890), 0.026)

    def test_distance(self):
        from utils import describe_distance, distance_km

        tehran, isfahan = (35.70, 51.40), (32.65, 51.67)
        km = distance_km(*tehran, *isfahan)
        self.assertTrue(330 < km < 350, km)
        self.assertEqual(distance_km(1, 1, 1, 1), 0)
        self.assertEqual(describe_distance(3), "کمتر از ۱۰ کیلومتر")
        self.assertEqual(describe_distance(341), "حدود 340 کیلومتر")

    def test_distance_is_coarse(self):
        from utils import describe_distance

        # two slightly different distances must give the same text (anti-trilateration)
        self.assertEqual(describe_distance(341.2), describe_distance(344.9))


class ProfileDatabaseTests(unittest.TestCase):
    def test_new_fields_roundtrip_and_clear(self):
        db = Database(":memory:")
        db.ensure_user(1)
        db.set_profile(1, nickname="سارا", province="فارس", city="شیراز",
                       lat=29.6, lon=52.5, photo="FILEID")
        user = db.get_user(1)
        self.assertEqual((user["nickname"], user["province"], user["city"]),
                         ("سارا", "فارس", "شیراز"))
        self.assertEqual((user["lat"], user["lon"], user["photo"]), (29.6, 52.5, "FILEID"))
        db.set_profile(1, lat=None, lon=None, photo=None)
        user = db.get_user(1)
        self.assertEqual((user["lat"], user["lon"], user["photo"]), (None, None, None))

    def test_old_database_is_migrated(self):
        import sqlite3
        import tempfile

        path = os.path.join(tempfile.mkdtemp(), "old.db")
        conn = sqlite3.connect(path)
        conn.execute(
            "CREATE TABLE users (id INTEGER PRIMARY KEY, gender TEXT, age INTEGER, "
            "state TEXT NOT NULL DEFAULT 'new', coins INTEGER NOT NULL DEFAULT 0, "
            "banned INTEGER NOT NULL DEFAULT 0, ref_by INTEGER, "
            "ref_rewarded INTEGER NOT NULL DEFAULT 0, referrals INTEGER NOT NULL DEFAULT 0, "
            "chats INTEGER NOT NULL DEFAULT 0, last_daily TEXT, "
            "created_at TEXT NOT NULL, last_seen TEXT NOT NULL)"
        )
        conn.execute("INSERT INTO users (id, gender, age, state, coins, created_at, last_seen) "
                     "VALUES (7, 'male', 30, 'ready', 4, 'x', 'x')")
        conn.commit()
        conn.close()

        db = Database(path)          # must add the new columns without losing data
        user = db.get_user(7)
        self.assertEqual((user["age"], user["coins"], user["nickname"]), (30, 4, None))
        db.set_profile(7, nickname="علی")
        self.assertEqual(db.get_user(7)["nickname"], "علی")
        Database(path)               # opening twice must not fail


class FriendDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")

    def test_request_accept_creates_one_friendship(self):
        status, rid = self.db.create_request(1, 2)
        self.assertEqual(status, "sent")
        self.assertEqual(self.db.answer_request(rid, 2, True), ("accepted", 1))
        fid = self.db.friendship_between(2, 1)
        self.assertIsNotNone(fid)
        self.assertEqual(self.db.friend_of(fid, 1), 2)
        self.assertEqual(self.db.friend_of(fid, 2), 1)
        self.assertIsNone(self.db.friend_of(fid, 3))      # outsiders get nothing
        self.assertEqual(self.db.answer_request(rid, 2, True), ("stale", None))
        self.assertEqual(self.db.create_request(1, 2), ("friends", None))

    def test_only_the_receiver_can_answer(self):
        _, rid = self.db.create_request(1, 2)
        self.assertEqual(self.db.answer_request(rid, 1, True), ("stale", None))
        self.assertEqual(self.db.answer_request(rid, 3, True), ("stale", None))
        self.assertIsNone(self.db.friendship_between(1, 2))

    def test_decline_and_duplicates(self):
        _, rid = self.db.create_request(1, 2)
        self.assertEqual(self.db.create_request(1, 2), ("pending", None))
        self.assertEqual(self.db.answer_request(rid, 2, False), ("declined", 1))
        self.assertIsNone(self.db.friendship_between(1, 2))
        self.assertEqual(self.db.create_request(1, 2)[0], "sent")   # may ask again later

    def test_mutual_requests_make_friends_at_once(self):
        self.db.create_request(1, 2)
        status, fid = self.db.create_request(2, 1)
        self.assertEqual(status, "mutual")
        self.assertEqual(self.db.friendship_between(1, 2), fid)

    def test_block_ends_friendship_and_prevents_new_ones(self):
        _, rid = self.db.create_request(1, 2)
        self.db.answer_request(rid, 2, True)
        self.db.add_block(1, 2)
        self.assertIsNone(self.db.friendship_between(1, 2))
        self.assertEqual(self.db.create_request(2, 1), ("blocked", None))

    def test_friend_limit(self):
        old = config.MAX_FRIENDS
        config.MAX_FRIENDS = 2
        try:
            for other in (10, 11):
                _, rid = self.db.create_request(1, other)
                self.assertEqual(self.db.answer_request(rid, other, True)[0], "accepted")
            self.assertEqual(self.db.create_request(1, 12), ("limit", None))
            self.assertEqual(self.db.create_request(12, 1), ("limit", None))
            self.assertEqual(len(self.db.friends_of(1)), 2)
        finally:
            config.MAX_FRIENDS = old

    def test_friends_of_and_remove(self):
        for other in (5, 6):
            _, rid = self.db.create_request(other, 1)
            self.db.answer_request(rid, 1, True)
        rows = self.db.friends_of(1)
        self.assertEqual(sorted(r["friend_id"] for r in rows), [5, 6])
        self.db.remove_friendship(rows[0]["fid"])
        self.assertEqual(len(self.db.friends_of(1)), 1)


class QuestionTests(unittest.TestCase):
    def test_banks_are_clean_and_unique(self):
        from questions import DARES, TRUTHS

        for bank in (TRUTHS, DARES):
            self.assertGreaterEqual(len(bank), 20)
            self.assertEqual(len(bank), len(set(bank)))
            for item in bank:
                self.assertTrue(item.strip())
                # a question must never trip our own contact-info filter
                self.assertFalse(contains_contact_info(item), item)


if __name__ == "__main__":
    unittest.main()
